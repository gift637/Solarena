# SolArena

> Compete. Trade. Win. — The first Solana-powered meme coin trading arena.

## Deploy to Vercel

### Option 1 — Vercel CLI (fastest)

```bash
npm i -g vercel
vercel
```

Follow the prompts. Your site will be live at a `*.vercel.app` URL in under 30 seconds.

### Option 2 — Vercel Dashboard (no CLI)

1. Push this folder to a GitHub / GitLab / Bitbucket repo
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the repo → click **Deploy**
4. Done. Vercel auto-detects the static config.

### Option 3 — Drag & Drop

1. Go to [vercel.com/new](https://vercel.com/new)
2. Drag the entire `solarena/` folder onto the page
3. Click **Deploy**

## Project Structure

```
solarena/
├── public/
│   └── index.html      # Full landing page
├── vercel.json         # Vercel routing config
├── package.json
└── README.md
```

## Custom Domain

After deploying, go to your project on vercel.com → **Settings → Domains** and add your custom domain.
